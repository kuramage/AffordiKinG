import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import tkinter.messagebox as mb
import threading
import mysql.connector

connection = mysql.connector.connect(user='root', password='1234', host='localhost', database='Affordiking')
cursor = connection.cursor()

def admin():
    def login():
        ad_id = username_entry.get()
        ad_pass = password_entry.get()

        query1 = "SELECT admin_name FROM admin WHERE admin_name = %s"
        query2 = "SELECT admin_password FROM admin WHERE admin_name = %s"

        cursor.execute(query1, (ad_id,))
        result1 = cursor.fetchone()
        cursor.execute(query2, (ad_id,))
        result2 = cursor.fetchone()

        if result1 and result2 and ad_pass == result2[0]:
            messagebox.showinfo("Login", "Login successful!")
            admin_window = tk.Toplevel(root)
            admin_window.title("Admin Interface")

            def execute_query():
                query_index = admin_query_var.get()
                if query_index == 1:
                    query = "SELECT DISTINCT branch_id, branch_name FROM branches"
                elif query_index == 2:
                    query = "SELECT SUM(amount) FROM payments"
                else:
                    return

                cursor.execute(query)
                results = cursor.fetchall()
                result_text.config(state=tk.NORMAL)
                result_text.delete("1.0", tk.END)
                for row in results:
                    result_text.insert(tk.END, str(row) + "\n")
                result_text.config(state=tk.DISABLED)

            admin_query_var = tk.IntVar()
            tk.Label(admin_window, text="Select Query:").pack()
            tk.Radiobutton(admin_window, text="List all the branches we have", variable=admin_query_var, value=1).pack(anchor=tk.W)
            tk.Radiobutton(admin_window, text="Show total amount of payment we get", variable=admin_query_var, value=2).pack(anchor=tk.W)

            execute_button = tk.Button(admin_window, text="Execute", command=execute_query)
            execute_button.pack()

            global result_text
            result_text = tk.Text(admin_window, height=10, width=50, state=tk.DISABLED)
            result_text.pack()
        else:
            messagebox.showerror("Login Error", "Wrong credentials")
            count.set(count.get() - 1)
            if count.get() == 0:
                root.destroy()

    admin_window = tk.Toplevel(root)
    admin_window.title("Admin Login")

    tk.Label(admin_window, text="Username:").pack()
    username_entry = tk.Entry(admin_window)
    username_entry.pack()

    tk.Label(admin_window, text="Password:").pack()
    password_entry = tk.Entry(admin_window, show="*")
    password_entry.pack()

    login_button = tk.Button(admin_window, text="Login", command=login)
    login_button.pack()

    global count
    count = tk.IntVar()
    count.set(3)

def embedded_sql():
    def update_input_fields():
        if embedded_sql_query_var.get() == 1:
            state_label.pack()
            state_entry.pack()
            cart_id_label.pack_forget()
            cart_id_entry.pack_forget()
            product_id_label.pack_forget()
            product_id_entry.pack_forget()
            customer_id_label.pack_forget()
            customer_id_entry.pack_forget()
        elif embedded_sql_query_var.get() == 2:
            state_label.pack_forget()
            state_entry.pack_forget()
            cart_id_label.pack()
            cart_id_entry.pack()
            product_id_label.pack()
            product_id_entry.pack()
            customer_id_label.pack()
            customer_id_entry.pack()
        else:
            state_label.pack_forget()
            state_entry.pack_forget()
            cart_id_label.pack_forget()
            cart_id_entry.pack_forget()
            product_id_label.pack_forget()
            product_id_entry.pack_forget()
            customer_id_label.pack_forget()
            customer_id_entry.pack_forget()

    def execute_embedded_sql_query():
        query_index = embedded_sql_query_var.get()
        result_text.config(state=tk.NORMAL)
        result_text.delete("1.0", tk.END) 
        
        if query_index == 1:
            st = state_entry.get()
            query = "SELECT * FROM customer WHERE address = %s"
            cursor.execute(query, (st,))
            result = cursor.fetchall()
            for row in result:
                result_text.insert(tk.END, str(row) + "\n")
        elif query_index == 2:
            cart_id = cart_id_entry.get()
            product_id = product_id_entry.get()
            customer_id = customer_id_entry.get()
            query1 = "SELECT * FROM cart"
            query2 = "INSERT INTO cart (cart_id, product_id, customer_id) VALUES (%s, %s, %s)"
            cursor.execute(query2, (cart_id, product_id, customer_id))
            connection.commit() 
            cursor.execute(query1)  
            result = cursor.fetchall()
            for row in result:
                result_text.insert(tk.END, str(row) + "\n")
        elif query_index == 3:
            query = "SELECT order_id, amount FROM payments WHERE amount > (SELECT AVG(amount) FROM payments)"
            cursor.execute(query)
            result = cursor.fetchall()
            for row in result:
                result_text.insert(tk.END, str(row) + "\n")
        result_text.config(state=tk.DISABLED)

    embedded_sql_window = tk.Toplevel(root)
    embedded_sql_window.title("Embedded SQL Interface")

    tk.Label(embedded_sql_window, text="Select Query:").pack()
    embedded_sql_query_var = tk.IntVar()
    embedded_sql_query_var.trace("w", lambda *args: update_input_fields())
    tk.Radiobutton(embedded_sql_window, text="Lists all the customers living in specific state", variable=embedded_sql_query_var, value=1).pack(anchor=tk.W)
    tk.Radiobutton(embedded_sql_window, text="Add Product to Cart", variable=embedded_sql_query_var, value=2).pack(anchor=tk.W)
    tk.Radiobutton(embedded_sql_window, text="List all orders whose amount is greater than the average order value of all orders", variable=embedded_sql_query_var, value=3).pack(anchor=tk.W)

    execute_button = tk.Button(embedded_sql_window, text="Execute", command=execute_embedded_sql_query)
    execute_button.pack()

    state_label = tk.Label(embedded_sql_window, text="Enter State Name:")
    state_entry = tk.Entry(embedded_sql_window)  

    cart_id_label = tk.Label(embedded_sql_window, text="Enter Cart ID:")
    cart_id_entry = tk.Entry(embedded_sql_window)
    product_id_label = tk.Label(embedded_sql_window, text="Enter Product ID:")
    product_id_entry = tk.Entry(embedded_sql_window)
    customer_id_label = tk.Label(embedded_sql_window, text="Enter Customer ID:")
    customer_id_entry = tk.Entry(embedded_sql_window)

    result_text = tk.Text(embedded_sql_window, height=10, width=50, state=tk.DISABLED)
    result_text.pack()


def execute_trigger_query():
    def update_entries():
        query_index = trigger_query_var.get()
        if query_index == 1:
            order_id_label.pack()
            order_id_entry.pack()
            payment_id_label.pack()
            payment_id_entry.pack()
            customer_id_label.pack()
            customer_id_entry.pack()
            amount_label.pack()
            amount_entry.pack()
        elif query_index == 2:

            order_id_label.pack()
            order_id_entry.pack()
            payment_id_label.pack()
            payment_id_entry.pack()
            customer_id_label.pack()
            customer_id_entry.pack()
            amount_label.pack()
            amount_entry.pack()

    def clear_entries():
        order_id_entry.delete(0, tk.END)
        payment_id_entry.delete(0, tk.END)
        customer_id_entry.delete(0, tk.END)
        amount_entry.delete(0, tk.END)

    def execute_payment():
        query_index = trigger_query_var.get()
        result_text_2.config(state=tk.NORMAL)
        result_text_2.delete("1.0", tk.END) 
        if query_index == 1:
            order_id = (order_id_entry.get())
            payment_id =(payment_id_entry.get())
            customer_id =(customer_id_entry.get())
            amount = (amount_entry.get())

            query_insert_payment = "INSERT INTO payments (order_id, payment_id, customer_id, amount) VALUES (%s, %s, %s, %s)"
            values = (order_id, payment_id, customer_id, amount)
            cursor.execute(query_insert_payment, values)
            connection.commit()

            query_update_rewards = "UPDATE royal_rewards SET reward = reward + FLOOR(%s / 10) WHERE customer_id = %s"
            values = (amount, customer_id)
            cursor.execute(query_update_rewards, values)
            connection.commit()

            result_text_2.insert(tk.END, "Payment added successfully and royal rewards updated.\n")
        elif query_index == 2:
            order_id = (order_id_entry.get())
            payment_id =(payment_id_entry.get())
            customer_id =(customer_id_entry.get())
            amount = int(amount_entry.get())

            if amount < 200:
                amount = 200

            query_insert_payment = "INSERT INTO payments (order_id, payment_id, customer_id, amount) VALUES (%s, %s, %s, %s)"
            values = (order_id, payment_id, customer_id, amount)
            cursor.execute(query_insert_payment, values)
            connection.commit()

            result_text_2.insert(tk.END, "Payment added successfully. Amount adjusted if less than 200.\n")

        result_text_2.config(state=tk.DISABLED)

    trigger_window = tk.Toplevel(root)
    trigger_window.title("Trigger Interface")

    tk.Label(trigger_window, text="Select Query:").pack()
    trigger_query_var = tk.IntVar()
    tk.Radiobutton(trigger_window, text="Update royal rewards after payment", variable=trigger_query_var, value=1).pack(anchor=tk.W)
    tk.Radiobutton(trigger_window, text="Update payment_amount, if less than 200 then set it 200", variable=trigger_query_var, value=2).pack(anchor=tk.W)

    order_id_label = tk.Label(trigger_window, text="Order ID:")
    order_id_label.pack_forget()   
    order_id_entry = tk.Entry(trigger_window)
    order_id_entry.pack_forget()   

    payment_id_label = tk.Label(trigger_window, text="Payment ID:")
    payment_id_label.pack_forget()   
    payment_id_entry = tk.Entry(trigger_window)
    payment_id_entry.pack_forget()   

    customer_id_label = tk.Label(trigger_window, text="Customer ID:")
    customer_id_label.pack_forget()   
    customer_id_entry = tk.Entry(trigger_window)
    customer_id_entry.pack_forget()   

    amount_label = tk.Label(trigger_window, text="Amount:")
    amount_label.pack_forget()   
    amount_entry = tk.Entry(trigger_window)
    amount_entry.pack_forget()   

    execute_button = tk.Button(trigger_window, text="Execute", command=execute_payment)
    execute_button.pack()

    clear_button = tk.Button(trigger_window, text="Clear Entries", command=clear_entries)
    clear_button.pack()

    global result_text_2
    result_text_2 = tk.Text(trigger_window, height=10, width=50, state=tk.DISABLED)
    result_text_2.pack()

    tk.Button(trigger_window, text="Update Entries", command=update_entries).pack()

    tk.Button(trigger_window, text="Execute Query 2", command=lambda: execute_payment()).pack()

def execute_query(query, values=None):
    cursor.execute(query, values)
    return cursor.fetchall()


def customer_interface():
    def show_signup_interface():
        login_frame.pack_forget()
        signup_frame.pack()
        signup_execute_button.pack()
        # item_add_frame.pack()

    def show_login_interface():
        signup_frame.pack_forget()
        login_frame.pack()
        log_execute_button.pack()
        execute_button.pack_forget()  # Hide execute button when showing login interface
        email_label.pack()
        email_entry.pack()
        password_label.pack()
        password_entry.pack()
        # item_add_frame.pack()
    
    # def show_item_add_interface():


    def customer_signup():
        # Retrieve user input from entry fields
        customer_id_val = f_name_entry.get()
        customer_name_val = m_name_entry.get()
        address_val = l_name_entry.get()
        phone_no_val = city_entry.get()
        email_val = state_entry.get()

        # Check if any of the entry fields are empty
        if not (customer_id_val and customer_name_val and address_val and phone_no_val and email_val):
            mb.showerror("Error", "Please fill in all the fields.")
            return

        # Check if user already exists
        query = "SELECT * FROM customer WHERE email = %s or phone_no=%s"
        values = (email_val, phone_no_val)
        cursor.execute(query, values)
        existing_user = cursor.fetchone()

        if existing_user:
            mb.showerror("Error", "User with this email or phone number already exists.")
        else:
            # Insert user data into the database
            query = "INSERT INTO customer (customer_id, customer_name, address, phone_no, email) VALUES (%s, %s, %s, %s, %s)"
            values = (customer_id_val, customer_name_val, address_val, phone_no_val, email_val)
            cursor.execute(query, values)
            connection.commit()
            mb.showinfo("Signup Successful", "You have successfully signed up!")
            show_login_interface()  # Switch to the login interface after signup

    def customer_login():
        email = email_entry.get()
        password = password_entry.get()

        # Query the user table to check if the entered credentials are valid
        query = "SELECT * FROM customer WHERE email = %s AND phone_no = %s"
        values = (email, password)
        cursor.execute(query, values)
        user_data = cursor.fetchone()
        global c_id
        if user_data:
            c_id=user_data[0]
            mb.showinfo("Login Successful", "You have successfully logged in!")
            execute_button.pack()  # Show execute button after successful login
            execute_customer_query()
        else:
            mb.showerror("Login Failed", "Invalid email or password.")
        
    def update_interface():
        query_index = admin_query_var.get()
        if query_index == 1:
            item_add_frame.pack_forget()
        elif query_index == 2:
            item_add_frame.pack()
            email_entry.pack_forget()
            password_entry.pack_forget()
        elif query_index == 3:
            item_remove_frame.pack()
            item_add_frame.pack_forget()
        elif query_index == 4:
            item_add_frame.pack_forget()    

    def execute_customer_query():
        query_index = admin_query_var.get()
        if query_index == 1:
            item_add_frame.pack_forget()
            query = "SELECT * FROM product"
            results = execute_query(query)
            result_text.config(state=tk.NORMAL)
            result_text.delete("1.0", tk.END)
            for row in results:
                result_text.insert(tk.END, str(row) + "\n")
            result_text.config(state=tk.DISABLED)
        elif query_index == 2:
            # item_add_frame.pack()
            email_entry.pack_forget()
            password_entry.pack_forget()
            cartID=cart_entry.get()
            productID=productID_entry.get()
            
            query = "insert into cart(cart_id, product_id,customer_id) values(%s,%s,%s)"
            values=(cartID,productID,c_id)
            query2 = "select * from cart"
            
            cursor.execute(query,values)
            connection.commit()
            results = execute_query(query2)
            result_text.config(state=tk.NORMAL)
            result_text.delete("1.0", tk.END)
            for row in results:
                result_text.insert(tk.END, str(row) + "\n")
            result_text.config(state=tk.DISABLED)
        elif query_index == 3:
            # item_remove_frame.pack()
            cartID=cart_rem.get()
            productID=product_rem.get()

            query = "delete from cart where cart_id=%s and product_id=%s"
            values=(cartID,productID)
            cursor.execute(query,values)
            connection.commit()
            query2="select * from cart"
            results = execute_query(query2)
            result_text.config(state=tk.NORMAL)
            result_text.delete("1.0", tk.END)
            for row in results:
                result_text.insert(tk.END, str(row) + "\n")
            result_text.config(state=tk.DISABLED)
        elif query_index == 4:
            query = "select * from cart where customer_id =%s"
            value=(c_id,) 
            results = execute_query(query,value)
            result_text.config(state=tk.NORMAL)
            result_text.delete("1.0", tk.END)
            for row in results:
                result_text.insert(tk.END, str(row) + "\n")
            result_text.config(state=tk.DISABLED) 
        elif query_index == 5:
            query = "select * from royal_rewards where customer_id =%s"
            value=(c_id,) 
            results = execute_query(query,value)
            result_text.config(state=tk.NORMAL)
            result_text.delete("1.0", tk.END)
            for row in results:
                result_text.insert(tk.END, str(row) + "\n")
            result_text.config(state=tk.DISABLED) 
        else:
            return

        

    customer_window = tk.Toplevel()
    customer_window.title("Customer Interface")

    login_frame = tk.Frame(customer_window)
    signup_button = tk.Button(login_frame, text="Sign Up", command=show_signup_interface)
    signup_button.pack()
    login_button = tk.Button(login_frame, text="Login", command=show_login_interface)
    login_button.pack()
    log_execute_button=tk.Button(login_frame, text="Execute_LogIn", command=customer_login)
    log_execute_button.pack_forget()
    
    signup_frame = tk.Frame(customer_window)
    signup_execute_button=tk.Button(signup_frame, text="Execute_SignUp", command=customer_signup)
    signup_execute_button.pack_forget()

    item_remove_frame=tk.Frame(customer_window)

    tk.Label(item_remove_frame,text="CartID").pack()
    cart_rem=tk.Entry(item_remove_frame)
    cart_rem.pack()
    tk.Label(item_remove_frame,text="ProductID").pack()
    product_rem=tk.Entry(item_remove_frame)
    product_rem.pack()
    item_add_frame=tk.Frame(customer_window)

    tk.Label(item_add_frame, text="CartID").pack()
    cart_entry = tk.Entry(item_add_frame)
    cart_entry.pack()
    tk.Label(item_add_frame, text="productID").pack()
    productID_entry = tk.Entry(item_add_frame)
    productID_entry.pack()
  

    tk.Label(signup_frame, text="Customer_id :").pack()
    f_name_entry = tk.Entry(signup_frame)
    f_name_entry.pack()
    tk.Label(signup_frame, text=" customer_name :").pack()
    m_name_entry = tk.Entry(signup_frame)
    m_name_entry.pack()
    tk.Label(signup_frame, text="Address :").pack()
    l_name_entry = tk.Entry(signup_frame)
    l_name_entry.pack()
    tk.Label(signup_frame, text="Phone_No :").pack()
    city_entry = tk.Entry(signup_frame)
    city_entry.pack()
    tk.Label(signup_frame, text="Email :").pack()
    state_entry = tk.Entry(signup_frame)
    state_entry.pack()

    signup_button = tk.Button(signup_frame, text="Sign Up", command=customer_signup)

    login_frame.pack()  # Show login interface by default

    # Entry fields for email and password
    email_label = tk.Label(customer_window, text="Email ID:")
    email_entry = tk.Entry(customer_window)
    password_label = tk.Label(customer_window, text="Password:")
    password_entry = tk.Entry(customer_window, show="*")

    # Frame to display admin queries and results
    admin_queries_frame = tk.Frame(customer_window)
    admin_query_var = tk.IntVar()
    tk.Label(admin_queries_frame, text="Select Query:").pack()
    ttk.Radiobutton(admin_queries_frame, text="Show Available Products", variable=admin_query_var, value=1,command=update_interface).pack(anchor=tk.W)
    ttk.Radiobutton(admin_queries_frame, text="Add Product to Customer Cart", variable=admin_query_var, value=2,command=update_interface).pack(anchor=tk.W)
    ttk.Radiobutton(admin_queries_frame, text="Remove Product from Customer Cart", variable=admin_query_var, value=3,command=update_interface).pack(anchor=tk.W)
    ttk.Radiobutton(admin_queries_frame, text="View Customer Cart", variable=admin_query_var, value=4,command=update_interface).pack(anchor=tk.W)
    tk.Radiobutton(admin_queries_frame, text="Show Customer Royal Rewards", variable=admin_query_var, value=5, command=update_interface).pack(anchor=tk.W)
    admin_queries_frame.pack()

    # Frame to display query results
    result_text = tk.Text(customer_window, height=10, width=50, state=tk.DISABLED)
    result_text.pack()

    # Button to execute selected query
    execute_button = ttk.Button(customer_window, text="Execute", command=execute_customer_query)


def display_results(results):
        result_text.config(state=tk.NORMAL)
        result_text.delete("1.0", tk.END)
        result_text.insert(tk.END, "Operation executed successfully.\n")
        for row in results:
            result_text.insert(tk.END, str(row) + "\n")
        result_text.config(state=tk.DISABLED)


root = tk.Tk()
root.title("AffordiKinG")

def open_admin_interface():
    admin()

def open_embedded_sql_interface():
    embedded_sql()

def open_triggers_interface():
    execute_trigger_query()

def open_customer_interface():
     customer_interface()    

admin_button = tk.Button(root, text="Admin", command=open_admin_interface)
admin_button.pack()

customer_button = ttk.Button(root, text="Customer", command=open_customer_interface)
customer_button.pack()

embedded_sql_button = tk.Button(root, text="Embedded SQL", command=open_embedded_sql_interface)
embedded_sql_button.pack()

triggers_button = tk.Button(root, text="Triggers", command=open_triggers_interface)
triggers_button.pack()

exit_button = tk.Button(root, text="Exit", command=root.quit)
exit_button.pack()

root.mainloop()

