-- Conflicting Trasnaction 1
-- session 1: Update reward for customer 3
START TRANSACTION;
UPDATE royal_rewards
SET reward = 50
WHERE customer_id = 3;


-- session 2: Update reward for customer 3
START TRANSACTION;
SAVEPOINT before_update_reward;
UPDATE royal_rewards
SET reward = 200
WHERE customer_id = 3;

-- Conflicting Transaction 2: Update branch for vendor 2
-- Session 1
START TRANSACTION;
UPDATE vendors
SET branch = 3
WHERE vendor_id = 2;



-- Session 2
START TRANSACTION;
UPDATE vendors
SET branch = 2
WHERE vendor_id = 2;



-- Transaction 3: Update product ID for customer 2
START TRANSACTION;
SAVEPOINT before_update_product_id;
UPDATE `order`
SET product_id = 1
WHERE customer_id = 2;
-- ROLLBACK; -- Use this to roll back to the savepoint
COMMIT;

-- Transaction 8: Update payment amount for order 1
START TRANSACTION;
SAVEPOINT before_update_payment_amount;
UPDATE payment
SET amount = 1000
WHERE payment_id = 1 AND order_id = 1;
-- ROLLBACK; -- Use this to roll back to the savepoint
COMMIT;

-- Transaction 9: Update feedback ratings for customer 1
START TRANSACTION;
SAVEPOINT before_update_feedback_ratings;
UPDATE feedback
SET ratings = '5'
WHERE customer_id = 1;
-- ROLLBACK; -- Use this to roll back to the savepoint
COMMIT;

-- Transaction 11: Update agent name for agent 2
START TRANSACTION;
SAVEPOINT before_update_agent_name;
UPDATE delivery
SET agent_name = 'agent2'
WHERE agent_id = 2;
-- ROLLBACK; -- Use this to roll back to the savepoint
COMMIT;
