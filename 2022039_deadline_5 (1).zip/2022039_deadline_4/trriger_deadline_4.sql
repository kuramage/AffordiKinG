USE affordiking;


#trriger -1
CREATE TRIGGER update_rewards_after_payment AFTER INSERT ON payments FOR EACH ROW UPDATE royal_rewards SET reward = reward + FLOOR(NEW.amount / 10) WHERE customer_id = NEW.customer_id


#trriger-2
DELIMITER //
CREATE TRIGGER update_payment_amount BEFORE INSERT ON payments
FOR EACH ROW
BEGIN
    IF NEW.amount < 200 THEN
        SET NEW.amount = 200;
    END IF;
END//
DELIMITER ;

